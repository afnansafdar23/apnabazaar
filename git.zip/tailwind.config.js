/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [],
  theme: {
    extend: {
      colors:{
        navbtn: '#019376',
      },
    },
  },
  plugins: [],
}
